@extends('layouts.app')
@section('content')

    <!-- content -->
    <div class="nk-content nk-content-fluid">
        <div class="container-xl wide-xl">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <div class="nk-block-head nk-block-head-sm">
                        <div class="nk-block-between">
                            <div class="nk-block-head-content">
                                <h3 class="nk-block-title page-title mb-0">Complete Order / Request</h3>
                                <div class="nk-block-des text-soft">
                                    <p>You have total {{ $transactionComplete->count() }} data.</p>
                                </div>
                            </div>
                            <div class="nk-block-head-content">
                                <div class="toggle-wrap nk-block-tools-toggle">
                                    <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1"
                                        data-target="pageMenu"><em class="icon ni ni-menu-alt-r"></em></a>
                                    <div class="toggle-expand-content" data-content="pageMenu">
                                        <ul class="nk-block-tools g-3">
                                            <li><a href="{{ url('transaction-revision') }}"
                                                    class="btn btn-white btn-outline-light"><em
                                                        class="icon ni ni-caution-fill text-warning"></em><span>Revision</span></a>
                                            </li>
                                            <li><a href="{{ url('transaction-request') }}"
                                                    class="btn btn-outline-light bg-white d-none d-sm-inline-flex"><em
                                                        class="icon ni ni-arrow-left"></em><span>Back</span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- datatable -->
                    <div class="components-preview">
                        <div class="nk-block nk-block-lg">
                            <div class="card card-bordered card-preview">
                                <div class="card-inner">
                                    <table class="datatable-init-export nk-tb-list nk-tb-ulist" data-auto-responsive="false" id="complete_table"
                                        data-export-title="Export">
                                        <thead>
                                            <tr class="nk-tb-item nk-tb-head">
                                                <th class="nk-tb-col"><span class="sub-text">Customer Name</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-mb"><span class="sub-text">Type</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-mb"><span class="sub-text">Address</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-md"><span class="sub-text">Contact</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-lg"><span class="sub-text">Account
                                                        Officer</span></th>
                                                <th class="nk-tb-col tb-col-lg"><span class="sub-text">Termination
                                                        Date</span></th>
                                                <th class="nk-tb-col tb-col-md"><span class="sub-text">Complete
                                                        Date</span></th>
                                                <th class="nk-tb-col tb-col-md"><span class="sub-text">Surveyor</span>
                                                </th>
                                                <th class="nk-tb-col nk-tb-col-tools text-right">
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($transactionComplete as $item)
                                                {{-- looping --}}
                                                <tr class="nk-tb-item">
                                                    <td class="nk-tb-col">
                                                        <div class="user-card">
                                                            @if ($item->is_revision == 2)
                                                            <div class="user-avatar d-none d-sm-flex" style="background-color: #FF8C00;">
                                                                <span>{{ $item->class->code }}</span>
                                                            </div>
                                                            @else
                                                            <div class="user-avatar
                                                                    @if ($item->covis_class_id == 1) bg-success
                                                                    @elseif ($item->covis_class_id == 2) bg-info
                                                                    @elseif ($item->covis_class_id == 3) bg-warning @endif d-none d-sm-flex">
                                                                <span>{{ $item->class->code }}</span>
                                                            </div>
                                                            @endif
                                                            
                                                            <div class="user-info">
                                                                <span class="tb-lead">{{ $item->customer->name }}
                                                                    <span
                                                                        class="dot dot-success d-md-none ml-1"></span></span>
                                                                <span>{{ $item->customer->project->name }}
                                                                    ({{ $item->customer->region->name }})
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="nk-tb-col tb-col-mb">
                                                        <div class="user-card">
                                                            <div class="user-info">
                                                                <span
                                                                    class="tb-lead">{{ $item->customer->covisType->name }}<span
                                                                        class="dot dot-success d-md-none ml-1"></span></span>
                                                                <span>
                                                                    {{ $item->customer->cityCustomer->name ?? '---' }},
                                                                    {{ $item->customer->provinceCustomer->name ?? '---' }}
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="nk-tb-col tb-col-mb">
                                                        {{ $item->customer->address }}
                                                    </td>
                                                    <td class="nk-tb-col tb-col-md">
                                                        <div class="user-card">
                                                            <div class="user-info">
                                                                <span
                                                                    class="tb-lead">{{ $item->customer->contact_name }}
                                                                    <span
                                                                        class="dot dot-success d-md-none ml-1"></span></span>
                                                                <span>{{ $item->customer->contact_no }}</span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="nk-tb-col tb-col-lg">
                                                        <div class="user-card">
                                                            <div class="user-info">
                                                                <span
                                                                    class="tb-lead">{{ $item->customer->ao_name }}
                                                                    <span
                                                                        class="dot dot-success d-md-none ml-1"></span></span>
                                                                <span>{{ $item->customer->ao_no }}</span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="nk-tb-col tb-col-lg">
                                                        <span>{{ Carbon\Carbon::parse($item->termination_date)->format('d M Y') }}</span>
                                                    </td>
                                                    <td class="nk-tb-col tb-col-lg">
                                                        <span><span>{{ Carbon\Carbon::parse($item->visited_at)->format('d M Y') }}</span></span>
                                                    </td>
                                                    <td class="nk-tb-col tb-col-md">
                                                        <span class="tb-status">{{ $item->surveyor->name }}</span>
                                                    </td>
                                                    <td class="nk-tb-col nk-tb-col-tools">
                                                        <ul class="nk-tb-actions gx-1">
                                                            <li class="nk-tb-action-hidden">
                                                                <a href="{{ url('transaction-complete-view', $item->uuid) }}"
                                                                    class="btn btn-trigger btn-icon" data-toggle="tooltip"
                                                                    data-placement="top" title="View">
                                                                    <em class="icon ni ni-external"></em>
                                                                </a>
                                                            </li>
                                                            <li class="nk-tb-action-hidden">
                                                                <a href="{{ url('print-transaction', $item->id) }}"
                                                                    target="_blank" class="btn btn-trigger btn-icon"
                                                                    data-toggle="tooltip" data-placement="top"
                                                                    title="Print Report">
                                                                    <em class="icon ni ni-printer"></em>
                                                                </a>
                                                            </li>
                                                            <li class="nk-tb-action-hidden">
                                                                <a href="#" class="toggle btn btn-trigger btn-icon btn-activated-deactivated"
                                                                    data-id="{{ $item->id }}"
                                                                    data-target="revision-modal" data-toggle="tooltip"
                                                                    data-placement="top" title="Revision">
                                                                    <em class="icon ni ni-caution"></em>
                                                                </a>
                                                            </li>
                                                            <li class="nk-tb-action-hidden">
                                                                <a href="#" class="toggle btn btn-trigger btn-icon btn-activated-deactivated"
                                                                    data-id="{{ $item->id }}"
                                                                    data-target="backdate-modal" data-toggle="tooltip"
                                                                    data-placement="top" title="Backdate">
                                                                    <em class="icon ni ni-calender-date"></em>
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <div class="drodown">
                                                                    <a href="#"
                                                                        class="dropdown-toggle btn btn-icon btn-trigger"
                                                                        data-toggle="dropdown"><em
                                                                            class="icon ni ni-more-h"></em></a>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /datatable -->

                </div>
            </div>
        </div>
    </div>
    <!-- /content -->

    <!-- modal revision -->
    <div class="nk-add-product toggle-slide toggle-slide-right" data-content="revision-modal" data-toggle-screen="any"
        data-toggle-overlay="true" data-toggle-body="true" data-simplebar>
        <div class="nk-block-head">
            <div class="nk-block-head-content">
                <h5 class="nk-block-title">Data Revision</h5>
                <div class="nk-block-des">
                    <p class="small text-primary">Are you sure want to revise this?</p>
                </div>
            </div>
        </div>
        <div class="nk-block">
            <form action="{{ url('transaction-revision') }}" method="POST">
                @csrf
                <div class="row g-3">
                    <div class="col-12">
                        <div class="form-group">
                            <label class="form-label" for="">Note</label>
                            <div class="form-control-wrap">
                                <textarea class="form-control" id="id" name="revision_note" rows="10" required></textarea>
                                <input type="hidden" class="id" id="id" name="id"> 
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <button class="btn btn-primary" type="submit"><span>Submit</span></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- /modal revision -->
    
    <!-- modal backdate -->
    <div class="nk-add-product toggle-slide toggle-slide-right" data-content="backdate-modal" data-toggle-screen="any"
        data-toggle-overlay="true" data-toggle-body="true" data-simplebar>
        <div class="nk-block-head">
            <div class="nk-block-head-content">
                <h5 class="nk-block-title">Data Backdate</h5>
                <div class="nk-block-des">
                    <p class="small text-primary">Are you sure want to backdate this? <span class="name"></span></p>
                </div>
            </div>
        </div>
        <div class="nk-block">
            <form action="{{ url('transaction-backdate') }}" method="POST">
                
                @csrf
                <div class="row g-3">
                    <div class="col-12">
                        <div class="form-group">
                            <label class="form-label" for="">Date</label>
                            <div class="form-control-wrap">
                                <input type="date" class="form-control" id="id" name="visited_at" required>
                                <input type="hidden" class="id" name="transaction_id">
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <button class="btn btn-primary" type="submit"><span>Submit</span></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- /modal backdate -->

@endsection

@push('addon-script')
<script>
    $('#complete_table').on('click','.btn-activated-deactivated', function(){
        let id = $(this).data('id');
        $('.id').val(id);
    })
</script>
@endpush
