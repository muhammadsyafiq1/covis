@extends('layouts.app')
@section('content')

    <!-- content -->
    <div class="nk-content nk-content-fluid">
        <div class="container-xl wide-xl">
            <div class="nk-content-inner">
                <div class="row">
                </div>
                <div class="nk-content-body">
                    <div class="nk-block-head nk-block-head-sm">
                        <div class="nk-block-between">
                            <div class="nk-block-head-content">
                                <h3 class="nk-block-title page-title mb-0">Order / Request</h3>
                                <div class="nk-block-des text-soft">
                                    <p>You have total {{ $transaction->count() }} data.</p>
                                </div>
                            </div>
                            <div class="nk-block-head-content">
                                <div class="toggle-wrap nk-block-tools-toggle">
                                    <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1"
                                        data-target="pageMenu"><em class="icon ni ni-menu-alt-r"></em></a>
                                    <div class="toggle-expand-content" data-content="pageMenu">
                                        <ul class="nk-block-tools g-3">
                                            <li><a href="{{ url('transaction-revision') }}"
                                                    class="btn btn-white btn-outline-light"><em
                                                        class="icon ni ni-caution-fill text-warning"></em><span>Revision</span></a>
                                            </li>
                                            <li><a href="{{ url('transaction-request-complete') }}"
                                                    class="btn btn-white btn-outline-light"><em
                                                        class="icon ni ni-check-circle-cut text-success"></em><span>Completed</span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- alert -->
                    @if ($message = Session::get('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <div class="alert-body">
                                {{ $message }}
                            </div>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            </button>
                        </div>
                    @elseif ($message = Session::get('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <div class="alert-body">
                                {{ $message }}
                            </div>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            </button>
                        </div>
                    @endif
                    <!-- /alert -->

                    <!-- datatable -->
                    <div class="components-preview">
                        <div class="nk-block nk-block-lg">
                            <div class="card card-bordered card-preview">
                                <div class="card-inner">
                                    <table class="datatable-init-export nk-tb-list nk-tb-ulist" data-auto-responsive="false"
                                        data-export-title="Export" id="customer_request_table">
                                        <thead>
                                            <tr class="nk-tb-item nk-tb-head">
                                                <th class="nk-tb-col"><span class="sub-text">Customer
                                                        Name</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-mb"><span class="sub-text">Type</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-mb"><span class="sub-text">Address</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-md"><span class="sub-text">Contact</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-lg"><span class="sub-text">Account
                                                        Officer</span></th>
                                                <th class="nk-tb-col tb-col-lg"><span class="sub-text">Termination
                                                        Date</span></th>
                                                <th class="nk-tb-col tb-col-md"><span class="sub-text">Status</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-md"><span class="sub-text">Assign
                                                        To</span></th>
                                                <th class="nk-tb-col nk-tb-col-tools text-right">
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        @foreach ($transaction as $tran)
                                            <tr class="nk-tb-item">
                                                <td class="nk-tb-col">
                                                    <div class="user-card">
                                                        <div
                                                            class="user-avatar 
                                                            @if ($tran->covis_class_id == 1) bg-success
                                                            @elseif ($tran->covis_class_id == 2) bg-info
                                                            @elseif ($tran->covis_class_id == 3) bg-warning @endif d-none d-sm-flex">
                                                            <span>{{ $tran->class->code }}</span>
                                                        </div>
                                                        <div class="user-info">
                                                            <span class="tb-lead">
                                                                {{ Str::of($tran->customer->name)->limit(30) }} <span
                                                                    class="dot dot-success d-md-none ml-1"></span>
                                                            </span>
                                                            <span>{{ $tran->customer->branch->name }}
                                                                ({{ $tran->customer->region->name }})
                                                            </span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="nk-tb-col tb-col-mb" nowrap>
                                                    <div class="user-card">
                                                        <div class="user-info">
                                                            <span class="tb-lead">
                                                                {{ $tran->customer->covisType->name }} <span
                                                                    class="dot dot-success d-md-none ml-1"></span>
                                                            </span>
                                                            <span>
                                                                {{ ucwords(strtolower($tran->customer->cityCustomer->name ?? '--')) }},
                                                                {{ ucwords(strtolower($tran->customer->provinceCustomer->name ?? '--')) }}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="nk-tb-col tb-col-mb" >
                                                    {{ $tran->customer->address }}
                                                </td>
                                                <td class="nk-tb-col tb-col-md" >
                                                    <div class="user-card">
                                                        <div class="user-info">
                                                            <span class="tb-lead">
                                                                {{ $tran->customer->contact_name }} <span
                                                                    class="dot dot-success d-md-none ml-1"></span>
                                                            </span>
                                                            <span>
                                                                {{ $tran->customer->contact_no }}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="nk-tb-col tb-col-lg">
                                                    <div class="user-card">
                                                        <div class="user-info">
                                                            <span class="tb-lead">
                                                                {{ $tran->customer->ao_name }} <span
                                                                    class="dot dot-success d-md-none ml-1"></span>
                                                            </span>
                                                            <span>
                                                                {{ $tran->customer->ao_no }}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="nk-tb-col tb-col-lg" nowrap>
                                                    <span>{{ Carbon\Carbon::parse($tran->termination_date)->format('d M Y') }}</span>
                                                </td>
                                                <td class="nk-tb-col tb-col-md" nowrap>
                                                    @if ($tran->status == 1)
                                                        <span class="tb-status text-info">To Be Confirm</span>
                                                    @elseif ($tran->status == 2)
                                                        <span class="tb-status text-warning">Waiting Approval</span>
                                                    @elseif ($tran->status == 3)
                                                        <span class="tb-status text-success">In-Progress</span>
                                                    @elseif ($tran->status == 4)
                                                        <span class="tb-status text-danger">Cancelled</span>
                                                    @elseif ($tran->status == 5)
                                                        <span class="tb-status text-primary">Done</span>
                                                    @endif
                                                </td>
                                                <td class="nk-tb-col tb-col-md" nowrap>
                                                    <span class="tb-status">{{ $tran->surveyor->name }}</span>
                                                </td>
                                                <td class="nk-tb-col nk-tb-col-tools" nowrap>
                                                    <ul class="nk-tb-actions gx-1">
                                                        <li class="nk-tb-action-hidden">
                                                            <a href="{{ url('transaction-request-view', $tran->uuid) }}"
                                                                class="btn btn-trigger btn-icon" data-toggle="tooltip"
                                                                data-placement="top" title="View">
                                                                <em class="icon ni ni-external"></em>
                                                            </a>
                                                        </li>
                                                        @if ($tran->status != 4)
                                                        <li class="nk-tb-action-hidden">
                                                            <a href="#"
                                                                data-id="{{ $tran->id }}"
                                                                data-name="{{ $tran->customer->name }}"
                                                                class="toggle btn btn-trigger btn-icon btn-activated-deactivated"
                                                                data-target="cancel-modal" 
                                                                data-toggle="tooltip"
                                                                data-placement="top" 
                                                                title="Cancel">
                                                                <em class="icon ni ni-cross-circle"></em>
                                                            </a>
                                                        </li>
                                                        @endif
                                                        <li>
                                                            <div class="drodown">
                                                                <a href="#"
                                                                    class="dropdown-toggle btn btn-icon btn-trigger"
                                                                    data-toggle="dropdown"><em
                                                                        class="icon ni ni-more-h"></em></a>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /datatable -->

                </div>
            </div>
        </div>
    </div>
    <!-- /content -->

    <!-- modal cancel -->
    <div class="nk-add-product toggle-slide toggle-slide-right" data-content="cancel-modal" data-toggle-screen="any"
        data-toggle-overlay="true" data-toggle-body="true" data-simplebar>
        <div class="nk-block-head">
            <div class="nk-block-head-content">
                <h5 class="nk-block-title">Cancel Order / Request</h5>
                <div class="nk-block-des">
                    <p class="small text-primary">Are you sure want to cancel this? <span id="name"></span> </p>
                </div>
            </div>
        </div>
        <div class="nk-block">
            <form action="{{ route('transaction-cancel') }}" method="get">
                @csrf
                <div class="row g-3">
                    <div class="col-12">
                        <div class="form-group">
                            <label class="form-label" for="">Note</label>
                            <div class="form-control-wrap">
                                <textarea class="form-control" id="cancel_note" name="cancel_note" rows="10" required></textarea>
                                <input type="hidden" name="id" id="id" class="form-control id">
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <button class="btn btn-primary" type="submit"><span>Submit</span></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- /modal cancel -->

@endsection

@push('addon-script')
<script>
    $('#customer_request_table').on('click','.btn-activated-deactivated', function(){
        let id = $(this).data('id');
        let name = $(this).data('name');
        $('.id').val(id);
        $('.name').val(name);
        $('#name').html(name);
    })
</script>
@endpush
