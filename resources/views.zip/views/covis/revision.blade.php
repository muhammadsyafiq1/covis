@extends('layouts.app')
@section('content')

    <!-- content -->
    <div class="nk-content nk-content-fluid">
        <div class="container-xl wide-xl">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <div class="nk-block-head nk-block-head-sm">
                        <div class="nk-block-between">
                            <div class="nk-block-head-content">
                                <h3 class="nk-block-title page-title mb-0">Customer Revision</h3>
                                <div class="nk-block-des text-soft">
                                    <p>You have total {{ $transaction->count() }} data.</p>
                                </div>
                            </div>
                            <div class="nk-block-head-content">
                                <div class="toggle-wrap nk-block-tools-toggle">
                                    <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1"
                                        data-target="pageMenu"><em class="icon ni ni-menu-alt-r"></em></a>
                                    <div class="toggle-expand-content" data-content="pageMenu">
                                        <ul class="nk-block-tools g-3">
                                            <li><a href="{{ url('transaction-request-complete') }}"
                                                    class="btn btn-white btn-outline-light"><em
                                                        class="icon ni ni-check-circle-cut text-success"></em><span>Complete</span></a>
                                            </li>
                                            <li><a href="{{ url('transaction-request') }}"
                                                    class="btn btn-outline-light bg-white d-none d-sm-inline-flex"><em
                                                        class="icon ni ni-arrow-left"></em><span>Back</span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- datatable -->
                    <div class="components-preview">
                        <div class="nk-block nk-block-lg">
                            <div class="card card-bordered card-preview">
                                <div class="card-inner">
                                    <table class="datatable-init-export nk-tb-list nk-tb-ulist" data-auto-responsive="false"
                                        data-export-title="Export">
                                        <thead>
                                            <tr class="nk-tb-item nk-tb-head">
                                                <th class="nk-tb-col"><span class="sub-text">Customer Name</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-mb"><span class="sub-text">Region</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-mb"><span class="sub-text">Type</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-md"><span class="sub-text">PIC /
                                                        Contact</span></th>
                                                <th class="nk-tb-col tb-col-lg"><span class="sub-text">Account
                                                        Officer</span></th>
                                                <th class="nk-tb-col tb-col-lg"><span class="sub-text">Assigned
                                                        To</span></th>
                                                <th class="nk-tb-col tb-col-lg"><span class="sub-text">Status</span></th>
                                                <th class="nk-tb-col nk-tb-col-tools text-right"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($transaction as $tran)
                                            <tr class="nk-tb-item">
                                                <td class="nk-tb-col">
                                                    <div class="user-card">
                                                        <div class="user-avatar d-none d-sm-flex" style="background-color: #FF8C00;">
                                                            <span>{{ substr($tran->customer->code ,1, 3)}}</span>
                                                        </div>
                                                        <div class="user-info">
                                                            <span class="tb-lead">{{ $tran->customer->name }} <span
                                                                    class="dot dot-success d-md-none ml-1"></span></span>
                                                                    <span>{{ $tran->customer->branch->name }}
                                                                    </span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="nk-tb-col tb-col-lg"><span>
                                                        ({{ $tran->customer->region->name }})
                                                    </span>
                                                </td>
                                                <td class="nk-tb-col tb-col-mb" nowrap>
                                                    <div class="user-card">
                                                        <div class="user-info">
                                                            <span class="tb-lead">
                                                                {{ $tran->customer->covisType->name }} <span
                                                                    class="dot dot-success d-md-none ml-1"></span>
                                                            </span>
                                                            <span>
                                                                {{ ucwords(strtolower($tran->customer->cityCustomer->name ?? '--')) }},
                                                                {{ ucwords(strtolower($tran->customer->provinceCustomer->name ?? '--')) }}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="nk-tb-col tb-col-md" nowrap>
                                                    <div class="user-card">
                                                        <div class="user-info">
                                                            <span class="tb-lead">
                                                                {{ $tran->customer->contact_name }} <span
                                                                    class="dot dot-success d-md-none ml-1"></span>
                                                            </span>
                                                            <span>
                                                                {{ $tran->customer->contact_no }}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="nk-tb-col tb-col-lg" nowrap>
                                                    <div class="user-card">
                                                        <div class="user-info">
                                                            <span class="tb-lead">
                                                                {{ $tran->customer->ao_name }} <span
                                                                    class="dot dot-success d-md-none ml-1"></span>
                                                            </span>
                                                            <span>
                                                                {{ !$tran->customer->ao_no ? 'N/A' : $tran->customer->ao_no }}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="nk-tb-col tb-col-lg">
                                                    <span class="tb-lead text-primary">{{ $tran->surveyor->name }}</span>
                                                </td>
                                                <td class="nk-tb-col tb-col-lg">
                                                    @if ($tran->is_revision == 1)
                                                        <span class="tb-lead text-success">In Progress</span>
                                                        
                                                    @else
                                                        <span class="tb-lead text-primary">Done</span>

                                                    @endif
                                                </td>
                                                <td class="nk-tb-col nk-tb-col-tools">
                                                    <ul class="nk-tb-actions gx-1">
                                                        <li class="nk-tb-action-hidden">
                                                            <a href="{{ url('transaction-revision-view',$tran->uuid) }}"
                                                                class="btn btn-trigger btn-icon" data-toggle="tooltip"
                                                                data-placement="top" title="View">
                                                                <em class="icon ni ni-external"></em>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <div class="drodown">
                                                                <a href="#" class="dropdown-toggle btn btn-icon btn-trigger"
                                                                    data-toggle="dropdown"><em
                                                                        class="icon ni ni-more-h"></em></a>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /datatable -->

                </div>
            </div>
        </div>
    </div>
    <!-- /content -->

@endsection
