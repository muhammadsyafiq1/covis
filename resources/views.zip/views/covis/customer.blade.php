@extends('layouts.app')
@section('content')

    <!-- content -->
    <div class="nk-content nk-content-fluid">
        <div class="container-xl wide-xl">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <div class="nk-block-head nk-block-head-sm">
                        <div class="nk-block-between">
                            <div class="nk-block-head-content">
                                <h3 class="nk-block-title page-title mb-0">Customer Data</h3>
                                <div class="nk-block-des text-soft">
                                    <p>You have total {{ $customer->count() }} data.</p>
                                </div>
                            </div>
                            <div class="nk-block-head-content">
                                <div class="toggle-wrap nk-block-tools-toggle">
                                    <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1"
                                        data-target="pageMenu"><em class="icon ni ni-menu-alt-r"></em></a>
                                    <div class="toggle-expand-content" data-content="pageMenu">
                                        <ul class="nk-block-tools g-3">
                                            <li class="nk-block-tools-opt">
                                                <div class="drodown">
                                                    <a href="#" class="dropdown-toggle btn btn-icon btn-primary"
                                                        data-toggle="dropdown"><em class="icon ni ni-plus"></em></a>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <ul class="link-list-opt no-bdr">
                                                            <li><a href="{{ url('customer-new') }}"><span>Add New
                                                                        Customer</span></a></li>
                                                            <li><a href="{{ url('customer-new-import') }}"><span>Import
                                                                        New Customer</span></a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- alert -->
                    @if ($message = Session::get('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <div class="alert-body">
                                {{ $message }}
                            </div>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            </button>
                        </div>
                    @elseif ($message = Session::get('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <div class="alert-body">
                                {{ $message }}
                            </div>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            </button>
                        </div>
                    @endif
                    <!-- /alert -->

                    <!-- datatable -->
                    <div class="components-preview">
                        <div class="nk-block nk-block-lg">
                            <div class="card card-bordered card-preview">
                                <div class="card-inner">
                                    <table class="datatable-init-export nk-tb-list nk-tb-ulist" data-auto-responsive="false"
                                        data-export-title="Export">
                                        <thead>
                                            <tr class="nk-tb-item nk-tb-head">
                                                <th class="nk-tb-col"><span class="sub-text">Customer Name</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-mb"><span class="sub-text">Region</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-mb"><span class="sub-text">Type</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-mb"><span class="sub-text">Address</span>
                                                </th>
                                                <th class="nk-tb-col tb-col-md"><span class="sub-text">PIC /
                                                        Contact</span></th>
                                                <th class="nk-tb-col tb-col-lg"><span class="sub-text">Account
                                                        Officer</span></th>
                                                <th class="nk-tb-col nk-tb-col-tools text-right"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($customer as $cust)
                                                <tr class="nk-tb-item">
                                                    <td class="nk-tb-col">
                                                        <div class="user-card">
                                                            <div class="user-avatar bg-dim-primary d-none d-sm-flex">
                                                                <span>{{ substr($cust->code ,1, 3)}}</span>
                                                            </div>
                                                            <div class="user-info">
                                                                <span class="tb-lead">{{ $cust->name }} <span class="dot dot-success d-md-none ml-1"></span></span>
                                                                <span>{{ $cust->project->code }} {{ $cust->branch->name }}</span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="nk-tb-col tb-col-lg">
                                                        <span class="tb-lead">{{ $cust->region->name }}</span>
                                                    </td>
                                                    <td class="nk-tb-col tb-col-mb">
                                                        <div class="user-card">
                                                            <div class="user-info">
                                                                <span
                                                                    class="tb-lead">{{ $cust->covisType->name }}<span
                                                                        class="dot dot-success d-md-none ml-1"></span></span>
                                                                <span>{{ !$cust->district_code ? '---' : ucwords(strtolower($cust->districtCustomer->name)) }},
                                                                    {{ !$cust->city_code ? '---' : ucwords(strtolower($cust->cityCustomer->name)) }}</span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="nk-tb-col tb-col-mb">
                                                        <span class="tb-lead">{{ $cust->address }}</span>
                                                    </td>
                                                    <td class="nk-tb-col tb-col-md">
                                                        <div class="user-card">
                                                            <div class="user-info">
                                                                <span class="tb-lead">{{ $cust->contact_name ?? 'N/A' }}<span
                                                                        class="dot dot-success d-md-none ml-1"></span></span>
                                                                <span>{{ $cust->contact_no ?? 'N/A'}}</span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="nk-tb-col tb-col-lg">
                                                        <div class="user-card">
                                                            <div class="user-info">
                                                                <span class="tb-lead">{{ $cust->ao_name ?? 'N/A'}} <span
                                                                        class="dot dot-success d-md-none ml-1"></span></span>
                                                                <span>{{ $cust->ao_no ?? 'N/A' }}</span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="nk-tb-col nk-tb-col-tools">
                                                        <ul class="nk-tb-actions gx-1">
                                                            <li class="nk-tb-action-hidden">
                                                                <a href="{{ url('customer-view', $cust->id) }}"
                                                                    class="btn btn-trigger btn-icon" data-toggle="tooltip"
                                                                    data-placement="top" title="View">
                                                                    <em class="icon ni ni-external"></em>
                                                                </a>
                                                            </li>
                                                            <li class="nk-tb-action-hidden">
                                                                <a href="#" class="toggle btn btn-icon"
                                                                    data-target="#order-modal" data-toggle="modal"
                                                                    data-id="{{ $cust->id }}"
                                                                    data-branch="{{ $cust->branch->id }}">
                                                                    <em class="icon ni ni-repeat" data-toggle="tooltip"
                                                                        data-placement="top" title="Order"></em>
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <div class="drodown">
                                                                    <a href="#"
                                                                        class="dropdown-toggle btn btn-icon btn-trigger"
                                                                        data-toggle="dropdown"><em
                                                                            class="icon ni ni-more-h"></em></a>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /datatable -->

                </div>
            </div>
        </div>
    </div>
    <!-- /content -->

    <!-- modal order -->
    <div class="modal right fade" id="order-modal" tabindex="-1" aria-labelledby="order-modalLabel" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12">
                            <h5 class="modal-title">Order / Request</h5>
                            <code class="small text-danger">* Required</code>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-12">
                            <form action="{{ url('post-customer-request') }}" method="POST">
                                @csrf
                                <div class="row g-3">
                                    <div class="col-12">
                                        <input type="hidden" name="covis_customer_id" id="covis_customer_id">
                                        <input type="hidden" name="covis_customer_branch_id" id="covis_customer_branch_id">
                                        <div class="form-group">
                                            <label class="form-label" for="user_id">Assigned To <code
                                                    class="text-danger ml-1">*</code></label>
                                            <div class="form-control-wrap">
                                                <select class="form-control" id="user_id" name="user_id" required>
                                                    <option disabled selected>--- Select ---</option>
                                                    @foreach ($surveyor as $data)
                                                        <option value="{{ $data->id }}">{{ $data->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label class="form-label" for="covis_class_id">Classification <code
                                                    class="text-danger ml-1">*</code></label>
                                            <div class="form-control-wrap">
                                                <select class="form-control" id="covis_class_id" name="covis_class_id"
                                                    required>
                                                    <option disabled selected>--- Select ---</option>
                                                    @foreach ($classification as $key => $value)
                                                        <option value="{{ $key }}">{{ $value }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label class="form-label" for="covis_priority_id">Priority <code
                                                    class="text-danger ml-1">*</code></label>
                                            <div class="form-control-wrap">
                                                <select class="form-control" id="covis_priority_id"
                                                    name="covis_priority_id" required>
                                                    <option disabled selected>--- Select ---</option>
                                                    @foreach ($priority as $key => $value)
                                                        <option value="{{ $key }}">{{ $value }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label class="form-label" for="termination_date">Termination Date <code
                                                    class="text-danger ml-1">*</code></label>
                                            <div class="form-control-wrap">
                                                <input type="text" class="form-control datepicker" id="termination_date"
                                                    name="termination_date" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label class="form-label" for="admin_note">Note <code
                                                    class="text-danger ml-1">*</code></label>
                                            <div class="form-control-wrap">
                                                <textarea class="form-control" id="admin_note"
                                                    name="admin_note" rows="3" required autocomplete="off"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 mt-3">
                                        <button class="btn btn-primary btn-block"
                                            type="submit"><span>Submit</span></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /modal order -->

@endsection

@push('addon-script')
    <script>
        $(document).ready(function() {
            $('#order-modal').on('show.bs.modal', function(event) {
                var div = $(event.relatedTarget);
                var modal = $(this);

                modal.find('#covis_customer_id').attr("value", div.data('id'));
                modal.find('#covis_customer_branch_id').attr("value", div.data('branch'));
            })
        })
    </script>
@endpush
